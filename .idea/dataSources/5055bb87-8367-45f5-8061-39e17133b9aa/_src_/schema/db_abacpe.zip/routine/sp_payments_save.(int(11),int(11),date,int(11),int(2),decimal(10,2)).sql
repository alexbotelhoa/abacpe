CREATE PROCEDURE sp_payments_save(IN pidpayment INT, IN pidclient INT, IN pdtpayment DATE, IN pidplan INT, IN pvlrecurrence INT(2), IN pvlpayment DECIMAL(10, 2))
  BEGIN
	
	IF pidpayment > 0 THEN
		
		UPDATE tb_payments
        SET 
			idclient = pidclient,
            dtpayment = pdtpayment,
            idplan = pidplan,
            vlrecurrence = pvlrecurrence,
            vlpayment = pvlpayment
        WHERE idpayment = pidpayment;
        
    ELSE
		
		INSERT INTO tb_payments (idclient, dtpayment, idplan, vlrecurrence, vlpayment) 
        VALUES(pidclient, pdtpayment, pidplan, pvlrecurrence, pvlpayment);
        
        SET pidpayment = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_payments WHERE idpayment = pidpayment;
    
END;

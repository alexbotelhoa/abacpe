CREATE PROCEDURE sp_plans_save(IN pidplan INT, IN pdesplan VARCHAR(128), IN pvlplan DECIMAL(10, 2))
  BEGIN
	
	IF pidplan > 0 THEN
		
		UPDATE tb_plans
        SET 
			desplan = pdesplan,
            vlplan = pvlplan
        WHERE idplan = pidplan;
        
    ELSE
		
		INSERT INTO tb_plans (desplan, vlplan) 
        VALUES(pdesplan, pvlplan);
        
        SET pidplan = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_plans WHERE idplan = pidplan;
    
END;

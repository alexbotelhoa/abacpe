CREATE VIEW vw_firstpayment AS
  SELECT
    `db_abacpe`.`tb_payments`.`idclient`       AS `idclient`,
    min(`db_abacpe`.`tb_payments`.`dtpayment`) AS `firstdtpayment`
  FROM `db_abacpe`.`tb_payments`
  GROUP BY `db_abacpe`.`tb_payments`.`idclient`
  ORDER BY `db_abacpe`.`tb_payments`.`idclient`;

CREATE VIEW vw_dtpayment_first AS
  SELECT
    `db_abacpe`.`tb_payments`.`idclient`       AS `idclient`,
    min(`db_abacpe`.`tb_payments`.`dtpayment`) AS `dtpayment`
  FROM `db_abacpe`.`tb_payments`
  GROUP BY `db_abacpe`.`tb_payments`.`idclient`
  ORDER BY `db_abacpe`.`tb_payments`.`idclient`;
